const mobileButton = document.querySelector('.mobile-button');
const mobileMenu = document.querySelector('.mobile-menu');

if (mobileButton && mobileMenu){

mobileButton.addEventListener('click', () => {

mobileMenu.classList.toggle('active');
mobileButton.classList.toggle('active');

});

}

const cursorGlow = document.querySelector('.cursor-glow');

window.addEventListener('mousemove', (e) => {

if(cursorGlow){

cursorGlow.style.left = e.clientX + 'px';
cursorGlow.style.top = e.clientY + 'px';

}

});

function createCursorSplash(x,y){

const count =
Math.floor(Math.random() * 8) + 3;

for(let i = 0; i < count; i++){

const splash =
document.createElement('div');

splash.classList.add('cursor-splash');

const randomX =
(Math.random() - 0.5) * 180 + 'px';

const randomY =
(Math.random() - 0.5) * 180 + 'px';

splash.style.left = x + 'px';
splash.style.top = y + 'px';

splash.style.setProperty('--x', randomX);
splash.style.setProperty('--y', randomY);

const size =
Math.random() * 10 + 4;

splash.style.width = size + 'px';
splash.style.height = size + 'px';

document.body.appendChild(splash);

setTimeout(() => {

splash.remove();

},1400);

}

}

function randomSplash(){

const x =
Math.random() * window.innerWidth;

const y =
Math.random() * window.innerHeight;

createCursorSplash(x,y);

const nextTime =
Math.random() * 2000 + 1000;

setTimeout(randomSplash,nextTime);

}

randomSplash();

const revealElements =
document.querySelectorAll(
'.reveal, .reveal-delay'
);

const observer =
new IntersectionObserver((entries) => {

entries.forEach((entry) => {

if(entry.isIntersecting){

entry.target.style.opacity = '1';
entry.target.style.transform = 'translateY(0px)';

}

});

},{
threshold:0.15
});

revealElements.forEach((element) => {

observer.observe(element);

});

window.addEventListener('scroll', () => {

const scrolled =
window.scrollY;

const rings =
document.querySelectorAll('.rotating-ring');

rings.forEach((ring,index) => {

const speed =
(index + 1) * 0.04;

ring.style.transform =
`translateY(${scrolled * speed}px)`;

});

});

const heroCard =
document.querySelector('.hero-card');

window.addEventListener('mousemove', (e) => {

if(!heroCard) return;

const x =
(window.innerWidth / 2 - e.clientX) / 35;

const y =
(window.innerHeight / 2 - e.clientY) / 35;

heroCard.style.transform =
`rotateY(${x}deg) rotateX(${-y}deg)`;

});

window.addEventListener('mouseleave', () => {

if(heroCard){

heroCard.style.transform =
'rotateY(0deg) rotateX(0deg)';

}

});

/* =========================
SUCCESS POPUP
========================= */

const form =
document.getElementById('contactForm');

const popup =
document.getElementById('successPopup');

const closePopup =
document.getElementById('closePopup');

if(form){

form.addEventListener('submit', async (e) => {

e.preventDefault();

const formData =
new FormData(form);

await fetch('send.php', {

method:'POST',
body:formData

});

popup.classList.add('active');

createPopupConfetti();

form.reset();

});

}

if(closePopup){

closePopup.addEventListener('click', () => {

popup.classList.remove('active');

});

}

function createPopupConfetti(){

const container =
document.querySelector('.popup-confetti');

if(!container) return;

container.innerHTML = '';

for(let i = 0; i < 80; i++){

const confetti =
document.createElement('span');

confetti.classList.add('mini-confetti');

confetti.style.left =
Math.random() * 100 + '%';

confetti.style.animationDelay =
Math.random() * 1 + 's';

confetti.style.animationDuration =
(Math.random() * 2 + 2) + 's';

confetti.style.width =
(Math.random() * 8 + 4) + 'px';

confetti.style.height =
(Math.random() * 14 + 6) + 'px';

container.appendChild(confetti);

}

}