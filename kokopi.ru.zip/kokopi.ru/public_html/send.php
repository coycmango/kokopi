<?php

if($_SERVER["REQUEST_METHOD"] == "POST"){

$name =
htmlspecialchars(trim($_POST['name']));

$contact =
htmlspecialchars(trim($_POST['contact']));

$message =
htmlspecialchars(trim($_POST['message']));

$to =
"info@kokopi.ru";

$subject =
"Новая заявка с сайта KOKOPI";

$body = "

<html>

<head>

<title>
Новая заявка
</title>

</head>

<body style='
background:#0b0b0f;
padding:40px;
font-family:Arial,sans-serif;
color:#ffffff;
'>

<div style='
max-width:620px;
margin:auto;
background:#111117;
border-radius:24px;
padding:40px;
border:1px solid rgba(255,255,255,0.08);
'>

<h2 style='
font-size:32px;
margin-bottom:30px;
color:#ff5a1f;
'>

Новая заявка KOKOPI

</h2>

<div style='margin-bottom:20px;'>

<div style='
font-size:13px;
opacity:0.5;
margin-bottom:8px;
text-transform:uppercase;
'>

Имя

</div>

<div style='font-size:20px;'>

$name

</div>

</div>

<div style='margin-bottom:20px;'>

<div style='
font-size:13px;
opacity:0.5;
margin-bottom:8px;
text-transform:uppercase;
'>

Контакт

</div>

<div style='font-size:20px;'>

$contact

</div>

</div>

<div style='margin-bottom:20px;'>

<div style='
font-size:13px;
opacity:0.5;
margin-bottom:8px;
text-transform:uppercase;
'>

Сообщение

</div>

<div style='
font-size:18px;
line-height:1.7;
'>

$message

</div>

</div>

</div>

</body>

</html>

";

$headers  =
"MIME-Version: 1.0" . "\r\n";

$headers .=
"Content-type:text/html;charset=UTF-8" . "\r\n";

$headers .=
"From: KOKOPI <info@kokopi.ru>" . "\r\n";

$headers .=
"Reply-To: info@kokopi.ru" . "\r\n";

if(
mail(
$to,
$subject,
$body,
$headers
)
){

http_response_code(200);

echo "success";

}else{

http_response_code(500);

echo "error";

}

}
?>