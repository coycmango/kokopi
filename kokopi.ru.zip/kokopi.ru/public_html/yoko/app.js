const products = [];

const categories = [
'Роллы',
'Суши',
'Сеты',
'Поке',
'Супы',
'Десерты'
];

const names = {

'Роллы':[
'Филадельфия',
'Калифорния',
'Лава',
'Темпура',
'Дракон',
'Канада',
'Спайси',
'Унаги'
],

'Суши':[
'Лосось',
'Тунец',
'Угорь',
'Креветка',
'Гребешок'
],

'Сеты':[
'Семейный',
'Премиум',
'Японский',
'Большой',
'Фирменный'
],

'Поке':[
'Лосось',
'Тунец',
'Креветка',
'Угорь'
],

'Супы':[
'Мисо',
'Рамен',
'Том Ям',
'Кимчи'
],

'Десерты':[
'Моти',
'Чизкейк',
'Матча',
'Тирамису'
]

};

let id = 1;

categories.forEach(category=>{

for(let i=0;i<10;i++){

const list = names[category];

const title =
list[
i % list.length
];

products.push({

id:id++,

name:
`${title} ${i+1}`,

category,

price:
Math.floor(
350 +
Math.random()*900
),

image:
`assets/products/${
category.toLowerCase()
}-${(i%5)+1}.png`,

description:
'Свежие ингредиенты и авторская подача.'

});

}

});

function renderProducts(list){

const container =
document.getElementById('products');

if(!container) return;

container.innerHTML='';

list.forEach(product=>{

container.innerHTML += `

<div class="product-card">

<img
src="${product.image}"
alt="${product.name}">

<h3>
${product.name}
</h3>

<div class="product-price">

${product.price} ₽

</div>

<div class="product-buttons">

<button
onclick="openProduct(${product.id})">

Подробнее

</button>

<button
onclick="addToCart(${product.id})">

В корзину

</button>

</div>

</div>

`;

});

}

document.addEventListener(
'DOMContentLoaded',
()=>{

renderProducts(products);

updateCartCounter();

}
);

const searchInput =
document.getElementById(
'search'
);

if(searchInput){

searchInput.addEventListener(
'input',
e=>{

const value =
e.target.value
.toLowerCase();

const filtered =
products.filter(product=>

product.name
.toLowerCase()
.includes(value)

);

renderProducts(filtered);

}
);

}

function filterCategory(category){

if(category==='all'){

renderProducts(products);

return;

}

const filtered =
products.filter(product=>

product.category===category

);

renderProducts(filtered);

}

function getCart(){

return JSON.parse(
localStorage.getItem('yoko_cart')
) || [];

}

function saveCart(cart){

localStorage.setItem(
'yoko_cart',
JSON.stringify(cart)
);

updateCartCounter();

}

function addToCart(id){

const cart = getCart();

const existing =
cart.find(item=>item.id===id);

if(existing){

existing.qty++;

}else{

cart.push({
id:id,
qty:1
});

}

saveCart(cart);

showToast(
'Товар добавлен в корзину'
);

}

function updateCartCounter(){

const badge =
document.querySelector(
'.cart-counter'
);

if(!badge) return;

const cart =
getCart();

let count = 0;

cart.forEach(item=>{

count += item.qty;

});

badge.textContent = count;

}

function removeFromCart(id){

let cart =
getCart();

cart =
cart.filter(
item=>item.id!==id
);

saveCart(cart);

renderCart();

}

function changeQty(id, action){

const cart =
getCart();

const item =
cart.find(
item=>item.id===id
);

if(!item) return;

if(action==='plus'){

item.qty++;

}

if(action==='minus'){

item.qty--;

if(item.qty<=0){

removeFromCart(id);
return;

}

}

saveCart(cart);

renderCart();

}

function renderCart(){

const container =
document.getElementById(
'cartItems'
);

if(!container) return;

const cart =
getCart();

container.innerHTML='';

let total = 0;

cart.forEach(item=>{

const product =
products.find(
p=>p.id===item.id
);

if(!product) return;

const sum =
product.price * item.qty;

total += sum;

container.innerHTML += `

<div class="cart-item">

<img
src="${product.image}"
alt="${product.name}">

<div class="cart-info">

<h3>${product.name}</h3>

<p>${product.price} ₽</p>

</div>

<div class="qty-box">

<button
onclick="changeQty(${item.id},'minus')">

−

</button>

<span>

${item.qty}

</span>

<button
onclick="changeQty(${item.id},'plus')">

+

</button>

</div>

<div class="cart-sum">

${sum} ₽

</div>

<button
class="remove-btn"
onclick="removeFromCart(${item.id})">

×

</button>

</div>

`;

});

const totalElement =
document.getElementById(
'totalPrice'
);

if(totalElement){

totalElement.textContent =
`${total} ₽`;

}

}

function getFavorites(){

return JSON.parse(
localStorage.getItem(
'yoko_favorites'
)
) || [];

}

function saveFavorites(data){

localStorage.setItem(
'yoko_favorites',
JSON.stringify(data)
);

}

function toggleFavorite(id){

let favorites =
getFavorites();

if(favorites.includes(id)){

favorites =
favorites.filter(
item=>item!==id
);

showToast(
'Удалено из избранного'
);

}else{

favorites.push(id);

showToast(
'Добавлено в избранное'
);

}

saveFavorites(
favorites
);

renderProducts(products);

}

function isFavorite(id){

const favorites =
getFavorites();

return favorites.includes(id);

}

<button
class="favorite-btn"
onclick="toggleFavorite(${product.id})">

${isFavorite(product.id)
? '♥'
: '♡'}

</button>

function openProduct(id){

const product =
products.find(
item=>item.id===id
);

if(!product) return;

const popup =
document.getElementById(
'productModal'
);

if(!popup) return;

popup.innerHTML = `

<div class="modal-overlay"
onclick="closeProduct()">

</div>

<div class="modal-window">

<button
class="modal-close"
onclick="closeProduct()">

×

</button>

<div class="modal-content">

<div class="modal-image">

<img
src="${product.image}"
alt="${product.name}">

</div>

<div class="modal-info">

<div class="modal-category">

${product.category}

</div>

<h2>

${product.name}

</h2>

<p>

${product.description}

</p>

<div class="modal-weight">

Вес: 280 г

</div>

<div class="modal-calories">

420 ккал

</div>

<div class="modal-price">

${product.price} ₽

</div>

<button
class="modal-add"
onclick="addToCart(${product.id})">

Добавить в корзину

</button>

</div>

</div>

</div>

`;

popup.classList.add(
'active'
);

document.body.style.overflow='hidden';

}

function closeProduct(){

const popup =
document.getElementById(
'productModal'
);

if(!popup) return;

popup.classList.remove(
'active'
);

document.body.style.overflow='';

}

document.addEventListener(
'keydown',
event=>{

if(
event.key==='Escape'
){

closeProduct();

}

}
);

function showToast(text){

const toast =
document.createElement('div');

toast.className =
'yoko-toast';

toast.innerText =
text;

document.body.appendChild(
toast
);

setTimeout(()=>{

toast.classList.add(
'show'
);

},50);

setTimeout(()=>{

toast.classList.remove(
'show'
);

setTimeout(()=>{

toast.remove();

},300);

},2500);

}

function placeOrder(){

const cart =
getCart();

if(cart.length===0){

showToast(
'Корзина пуста'
);

return;

}

const orders =
JSON.parse(
localStorage.getItem(
'yoko_orders'
)
) || [];

orders.unshift({

id:
Math.floor(
100000 +
Math.random()*900000
),

date:
new Date()
.toLocaleString(),

status:
'Готовится',

items:cart

});

localStorage.setItem(

'yoko_orders',

JSON.stringify(
orders
)

);

localStorage.removeItem(
'yoko_cart'
);

showSuccessPopup();

}

function showSuccessPopup(){

const popup =
document.getElementById(
'orderSuccess'
);

if(!popup) return;

popup.classList.add(
'active'
);

createConfetti();

}

function createConfetti(){

const box =
document.querySelector(
'.confetti-box'
);

if(!box) return;

for(let i=0;i<80;i++){

const item =
document.createElement('span');

item.className =
'confetti-piece';

item.style.left =
Math.random()*100+'%';

item.style.animationDelay =
Math.random()*2+'s';

item.style.transform =
`rotate(${Math.random()*360}deg)`;

box.appendChild(item);

}

}

function getBonusBalance(){

return parseInt(

localStorage.getItem(
'yoko_bonus'
)

) || 2450;

}

function addBonus(points){

const current =
getBonusBalance();

localStorage.setItem(

'yoko_bonus',

current + points

);

}

let total = 0;

cart.forEach(item=>{

const product =
products.find(
p=>p.id===item.id
);

if(product){

total +=
product.price *
item.qty;

}

});

addBonus(
Math.floor(total*0.05)
);

function renderOrders(){

const container =
document.getElementById(
'ordersList'
);

if(!container) return;

const orders =
JSON.parse(
localStorage.getItem(
'yoko_orders'
)
) || [];

container.innerHTML='';

orders.forEach(order=>{

container.innerHTML += `

<div class="order-row">

<div>

Заказ №${order.id}

</div>

<div>

${order.date}

</div>

<div>

${order.status}

</div>

</div>

`;

});

}

const promoCodes = {

WELCOME10:10,
YOKO15:15,
SUSHI20:20,
DELIVERY25:25

};

function applyPromo(){

const input =
document.getElementById(
'promoInput'
);

if(!input) return;

const code =
input.value.trim().toUpperCase();

if(!promoCodes[code]){

showToast(
'Промокод не найден'
);

return;

}

localStorage.setItem(
'yoko_promo',
promoCodes[code]
);

showToast(
`Скидка ${promoCodes[code]}% применена`
);

renderCart();

}

const discount =
parseInt(
localStorage.getItem(
'yoko_promo'
)
) || 0;

const discountSum =
Math.round(
total * discount / 100
);

const finalTotal =
total - discountSum;

document.getElementById(
'totalPrice'
).innerText =
finalTotal + ' ₽';

function getRecommendations(){

const shuffled =
[...products]

.sort(
()=>Math.random()-0.5
)

.slice(0,4);

return shuffled;

}

function renderRecommendations(){

const block =
document.getElementById(
'recommendedProducts'
);

if(!block) return;

block.innerHTML='';

getRecommendations()
.forEach(product=>{

block.innerHTML += `

<div class="recommend-card">

<img
src="${product.image}">

<h4>
${product.name}
</h4>

<div>
${product.price} ₽
</div>

<button
onclick="addToCart(${product.id})">

Добавить

</button>

</div>

`;

});

}

saveRecent(product.id);

function saveRecent(id){

let recent =
JSON.parse(
localStorage.getItem(
'yoko_recent'
)
) || [];

recent =
recent.filter(
item=>item!==id
);

recent.unshift(id);

recent =
recent.slice(0,8);

localStorage.setItem(

'yoko_recent',

JSON.stringify(recent)

);

}

function renderRecent(){

const block =
document.getElementById(
'recentProducts'
);

if(!block) return;

const ids =
JSON.parse(
localStorage.getItem(
'yoko_recent'
)
) || [];

block.innerHTML='';

ids.forEach(id=>{

const product =
products.find(
item=>item.id===id
);

if(!product) return;

block.innerHTML += `

<div class="recent-card">

<img
src="${product.image}">

<div>
${product.name}
</div>

</div>

`;

});

}

const banners = [

{
title:'Сет недели',
text:'Скидка 25%',
image:'assets/banner-1.png'
},

{
title:'Бесплатная доставка',
text:'от 1990 ₽',
image:'assets/banner-2.png'
},

{
title:'Ролл в подарок',
text:'при заказе от 3000 ₽',
image:'assets/banner-3.png'
}

];

function renderBanners(){

const slider =
document.getElementById(
'promoSlider'
);

if(!slider) return;

banners.forEach(item=>{

slider.innerHTML += `

<div class="promo-slide">

<img
src="${item.image}">

<div class="promo-content">

<h2>
${item.title}
</h2>

<p>
${item.text}
</p>

</div>

</div>

`;

});

}

let currentSlide = 0;

function startSlider(){

const slides =
document.querySelectorAll(
'.promo-slide'
);

if(!slides.length) return;

setInterval(()=>{

slides[currentSlide]
.classList.remove(
'active'
);

currentSlide++;

if(
currentSlide>=slides.length
){

currentSlide=0;

}

slides[currentSlide]
.classList.add(
'active'
);

},5000);

}

function autocomplete(text){

return products.filter(product=>

product.name
.toLowerCase()
.includes(
text.toLowerCase()
)

).slice(0,5);

}

function showAutocomplete(value){

const block =
document.getElementById(
'searchResults'
);

if(!block) return;

block.innerHTML='';

autocomplete(value)
.forEach(product=>{

block.innerHTML += `

<div
class="search-item"
onclick="openProduct(${product.id})">

${product.name}

</div>

`;

});

}

const deliveryStatuses = [

'Заказ принят',
'Передан на кухню',
'Готовится',
'Передан курьеру',
'Курьер в пути',
'Доставлен'

];

function startTracking(){

let step = 0;

const status =
document.getElementById(
'deliveryStatus'
);

if(!status) return;

status.innerText =
deliveryStatuses[0];

const timer =
setInterval(()=>{

step++;

if(
step >= deliveryStatuses.length
){

clearInterval(timer);

return;

}

status.innerText =
deliveryStatuses[step];

},4000);

}

