const svg = document.getElementById("overlaySvg");

const img =
document.querySelector(
".floor-template"
);

const floorButtons =
document.querySelectorAll(
".floor"
);

const modal =
document.getElementById(
"apartmentModal"
);

const closeBtn =
document.getElementById(
"closeModal"
);

/* пример структуры */
const polygonsByFloor = {

1:[

{
id:1,
number:"101",
rooms:"1",
area:"42 м²",
view:"Двор",
status:"free",
layout:"./img/layouts/1room-42.jpg",

coords:[
[80,140],
[230,120],
[320,220],
[300,420],
[120,440],
[60,300]
]

},

{
id:2,
number:"102",
rooms:"2",
area:"64 м²",
view:"Город",
status:"free",
layout:"./img/layouts/2room-64.jpg",

coords:[
[340,180],
[620,170],
[690,420],
[470,520],
[320,360]
]

}

]

};

function renderFloor(floor){

svg.innerHTML="";

const apartments =
polygonsByFloor[floor] || [];

document.getElementById(
"floorTitle"
).textContent=floor;

let available=0;
let sold=0;
let areaSum=0;

apartments.forEach(ap=>{

if(ap.status==="free")
available++;

if(ap.status==="sold")
sold++;

areaSum += parseFloat(
ap.area
);

const polygon =
document.createElementNS(
"http://www.w3.org/2000/svg",
"polygon"
);

polygon.setAttribute(

"points",

ap.coords.map(
p=>p.join(",")
).join(" ")

);

polygon.dataset.id =
ap.id;

polygon.classList.add(
ap.status
);

polygon.addEventListener(
"click",
()=>openApartment(ap)
);

svg.appendChild(
polygon
);

});

document.getElementById(
"availableCount"
).textContent=available;

document.getElementById(
"soldCount"
).textContent=sold;

document.getElementById(
"avgArea"
).textContent=

apartments.length ?

Math.round(
areaSum /
apartments.length
)+" м²"

:

"0 м²";

}

function setViewbox(){

svg.setAttribute(

"viewBox",

`0 0 ${img.naturalWidth} ${img.naturalHeight}`

);

svg.setAttribute(

"preserveAspectRatio",

"xMidYMid meet"

);

}

function openApartment(ap){

document.getElementById(
"aptNumber"
).textContent=ap.number;

document.getElementById(
"aptFloor"
).textContent=

document.getElementById(
"floorTitle"
).textContent;

document.getElementById(
"aptArea"
).textContent=ap.area;

document.getElementById(
"aptRooms"
).textContent=ap.rooms;

document.getElementById(
"aptView"
).textContent=ap.view;

document.getElementById(
"aptLayout"
).src=ap.layout;

modal.classList.remove(
"hidden"
);

}

closeBtn.addEventListener(
"click",
()=>modal.classList.add(
"hidden"
)
);

modal.addEventListener(
"click",
e=>{

if(e.target===modal){

modal.classList.add(
"hidden"
);

}

});

floorButtons.forEach(btn=>{

btn.addEventListener(
"click",
()=>{

floorButtons.forEach(
b=>b.classList.remove(
"active"
)
);

btn.classList.add(
"active"
);

renderFloor(
btn.dataset.floor
);

}

);

});

img.onload=()=>{

setViewbox();

renderFloor(1);

};

if(img.complete){

setViewbox();

renderFloor(1);

}