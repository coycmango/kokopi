document.querySelectorAll('.carousel').forEach(carousel=>{
carousel.addEventListener('wheel', e=>{
e.preventDefault();
carousel.scrollLeft += e.deltaY;
});
});