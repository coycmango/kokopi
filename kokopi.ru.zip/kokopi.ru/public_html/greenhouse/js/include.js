async function loadIncludes(){

try{

const headerContainer =
document.getElementById(
"header-placeholder"
);

const footerContainer =
document.getElementById(
"footer-placeholder"
);



if(headerContainer){

const headerResponse =
await fetch(
"./includes/header.html"
);

headerContainer.innerHTML =
await headerResponse.text();

initBurger();

}



if(footerContainer){

const footerResponse =
await fetch(
"./includes/footer.html"
);

footerContainer.innerHTML =
await footerResponse.text();

}

}

catch(error){

console.error(

"Ошибка загрузки include:",

error

);

}

}



function initBurger(){

const burger =
document.getElementById(
"burgerBtn"
);

const nav =
document.getElementById(
"headerNav"
);



if(!burger || !nav){

return;

}



burger.addEventListener(

"click",

()=>{

nav.classList.toggle(

"open"

);

document.body.classList.toggle(

"menu-open"

);

}

);



document.querySelectorAll(
"#headerNav a"
).forEach(link=>{

link.addEventListener(

"click",

()=>{

nav.classList.remove(

"open"

);

document.body.classList.remove(

"menu-open"

);

}

);

});



window.addEventListener(

"resize",

()=>{

if(

window.innerWidth > 900

){

nav.classList.remove(

"open"

);

document.body.classList.remove(

"menu-open"

);

}

}

);

}



document.addEventListener(

"DOMContentLoaded",

loadIncludes

);