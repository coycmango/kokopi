<?php

header('Content-Type: application/json; charset=utf-8');

if ($_SERVER["REQUEST_METHOD"] !== "POST") {

echo json_encode([
"success" => false,
"message" => "Метод не поддерживается"
]);

exit;

}


/* ======================
CONFIG
====================== */

$to = "info@kokopi.ru";


/* ======================
INPUT
====================== */

$name = trim($_POST["name"] ?? "");
$phone = trim($_POST["phone"] ?? "");
$email = trim($_POST["email"] ?? "");
$message = trim($_POST["message"] ?? "");
$form = trim($_POST["form"] ?? "unknown");


/* ======================
VALIDATION
====================== */

if(empty($name) || empty($phone)){

echo json_encode([

"success" => false,

"message" => "Заполните обязательные поля"

]);

exit;

}


/* ======================
SANITIZE
====================== */

$name = htmlspecialchars($name);
$phone = htmlspecialchars($phone);
$email = htmlspecialchars($email);
$message = htmlspecialchars($message);
$form = htmlspecialchars($form);


/* ======================
BUILD EMAIL
====================== */

$subject = "Новая заявка Green House";

$body = "

Новая заявка с сайта Green House

----------------------------

Форма: {$form}

Имя: {$name}

Телефон: {$phone}

Email: {$email}

Сообщение:

{$message}

----------------------------

Дата: ".date("d.m.Y H:i:s")."

IP: ".$_SERVER["REMOTE_ADDR"]."

";


$headers = [];

$headers[] = "MIME-Version: 1.0";

$headers[] = "Content-Type: text/plain; charset=UTF-8";

$headers[] = "From: Green House Site <noreply@".$_SERVER["HTTP_HOST"].">";

$headers[] = "Reply-To: ".$email;

$headers = implode("\r\n",$headers);


/* ======================
SEND
====================== */

$result = mail(

$to,

"=?UTF-8?B?".base64_encode($subject)."?=",

$body,

$headers

);


/* ======================
RESPONSE
====================== */

if($result){

echo json_encode([

"success" => true,

"message" => "Заявка отправлена"

]);

}

else{

echo json_encode([

"success" => false,

"message" => "Ошибка отправки"

]);

}

?>